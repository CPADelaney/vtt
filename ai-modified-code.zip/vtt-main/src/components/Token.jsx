// js/components/Token.jsx
import React, { memo } from 'react';

/**
 * Renders a single token at a given position.
 *
 * Props:
 *  - id: unique identifier
 *  - position: { x: number, y: number }
 *  - stats: object (e.g. { hp: 100, maxHp: 100, name: '...' }) - Currently unused in rendering, but good practice to pass
 *  - isSelected: boolean
 *  - onClick: callback for handling clicks (added stopPropagation internally)
 */
export const Token = memo(function Token({
  id,
  position,
  stats, // Stats are passed but not rendered by the Token component itself
  isSelected,
  onClick // Optional onClick handler, added for consistency
}) {
  // Internal click handler that stops propagation
  const handleClick = (e) => {
    e.stopPropagation(); // Prevent this click from triggering parent handlers (like the tabletop's mousedown for selection/ping)
    // If an external onClick was provided, call it
    if (onClick) {
      onClick(e);
    }
  };

  return (
    <div
      id={id}
      className={`token ${isSelected ? 'selected' : ''}`}
      style={{
        position: 'absolute',
        left: `${position.x}px`,
        top: `${position.y}px`,
        // translates so that (x,y) is the center of the token
        transform: 'translate(-50%, -50%)',
        // Note: width/height, background are defined in styles.css
        // zIndex is defined in styles.css
      }}
      // Data attribute is a good way to store extra info on the DOM element
      data-stats={stats ? JSON.stringify(stats) : undefined}
      onClick={handleClick} // Use the internal handler
    />
  );
});