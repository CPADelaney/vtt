import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
// Only import SplitPane once
import SplitPane from 'react-split-pane';
import 'react-split-pane/style.css';
import _ from 'lodash';

// Hooks
import { useTokenDrag } from '../hooks/useTokenDrag';
import { useTokenSelection } from '../hooks/useTokenSelection';
import { useContextMenu } from '../hooks/useContextMenu';
import { useGridSnapping } from '../hooks/useGridSnapping';
import { useCampaignManager } from '../hooks/useCampaignManager';
import { useAutoSave } from '../hooks/useAutoSave';
import { useStateWithHistory } from '../hooks/useStateWithHistory';
import { useDiceManager } from '../hooks/useDiceManager'; // Import DiceManager hook
import { useSystemManager } from '../hooks/useSystemManager'; // Import SystemManager hook


// Components
import { ZoomableContainer } from './ZoomableContainer';
import { Grid } from './Grid';
import { Token } from './Token';
import { Controls } from './Controls';
import { Sidebar } from './Sidebar'; // Use the refactored Sidebar
import { Ping } from './Ping'; // Import the Ping component

// Constants
const MIN_SCALE = 0.3;
const MAX_SCALE = 3;
const ZOOM_FACTOR = 0.1;
const DEFAULT_SQUARE_SIZE = 50;
const DEFAULT_HEX_SIZE = 30;

// Note: Ping component definition moved outside for performance

export default function VirtualTabletop() {
  // Initialize managers - potentially could come from props or Context in a larger app
  const diceManager = useDiceManager('DM'); // Assuming DM controls the VTT session
  const systemManager = useSystemManager(); // Assume this is initialized here or higher up

  // 1) Single Source of Truth - Use useStateWithHistory
  // Include combat state and action history in the main gameState
  const [gameState, setDirectState, updateGameState, undoGameState, historyInfo] = useStateWithHistory({
    isHexGrid: false,
    tokens: [],
    scale: 1,
    position: { x: 0, y: 0 },
    inCombat: false, // Added combat state
    actionHistory: [], // Added action history
  }, {
    maxHistory: 50,
    onUndo: (prevState) => {
      // console.log('[DEBUG] Undid to state.'); // Removed excessive debug
    }
  });
  // Destructure state for easier access
  const { isHexGrid, tokens, scale, position, inCombat, actionHistory } = gameState;

  const handleUndo = useCallback(() => {
    if (!historyInfo.canUndo) {
      // console.log('[DEBUG] No more states to undo.'); // Removed excessive debug
      return;
    }
    undoGameState();
  }, [undoGameState, historyInfo.canUndo]);

  // Basic Redo handler (add if needed, useStateWithHistory provides it)
  // const handleRedo = historyInfo.canRedo ? redoGameState : null;


  // 2) Load & Save from campaignManager
  const { saveState, loadState } = useCampaignManager('default-campaign');

  // 3) Token selection and deletion
  const { selectedTokenIds, selectTokenId, clearSelection, startMarquee } = useTokenSelection();

  // Update all setGameState calls to use updateGameState (or setDirectState for temp)
  const handleDeleteTokens = useCallback(() => {
    // console.log('[DEBUG] Deleting tokens', Array.from(selectedTokenIds)); // Removed excessive debug
    updateGameState(prev => ({
      ...prev,
      tokens: prev.tokens.filter(t => !selectedTokenIds.has(t.id))
    }));
    clearSelection();
  }, [selectedTokenIds, clearSelection, updateGameState]);

  const initialLoadDoneRef = useRef(false);

  // Add keyboard shortcuts for deletion and Undo/Redo
  useEffect(() => {
    function handleKeyDown(e) {
      // Only handle if no input elements are focused
      if (document.activeElement.tagName === 'INPUT' ||
          document.activeElement.tagName === 'TEXTAREA') {
        return;
      }

      // Check if Delete or Backspace was pressed and there are selected tokens
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedTokenIds.size > 0) {
        // Prevent default browser behavior (like browser back on Backspace)
        e.preventDefault();
        // console.log('[DEBUG] Delete/Backspace pressed'); // Removed excessive debug
        handleDeleteTokens();
      }
      // Undo (Ctrl+Z or Cmd+Z) is handled globally by useStateWithHistory effect
      // Redo (Ctrl+Y or Cmd+Y, or Ctrl+Shift+Z or Cmd+Shift+Z) is handled globally by useStateWithHistory effect
    }

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedTokenIds, handleDeleteTokens]);

  // Load entire state on mount
  useEffect(() => {
    if (initialLoadDoneRef.current) return;

    // console.log('[DEBUG] Loading campaign state on mount...'); // Removed excessive debug
    const loaded = loadState();
    if (loaded) {
      // console.log('[DEBUG] Loaded fullState:', loaded); // Removed excessive debug
      setDirectState(loaded); // Load state directly without adding to history
      initialLoadDoneRef.current = true;
    } else {
      // console.log('[DEBUG] No saved state found... using defaults'); // Removed excessive debug
      initialLoadDoneRef.current = true;
    }
  }, [loadState, setDirectState, initialLoadDoneRef]);

  // Auto-save entire gameState, debounced 2s
  const persistGameState = useCallback((full) => {
    saveState({
      ...full,
      timestamp: Date.now()
    });
  }, [saveState]);

  // useAutoSave watches the main gameState object (including combat/history)
  useAutoSave(gameState, persistGameState, 2000);

  // Debug watchers - can be removed for production
  // const prevTokensRef = useRef(tokens);
  // useEffect(() => {
  //   if (prevTokensRef.current !== tokens) {
  //     console.log('[DEBUG] Tokens changed.');
  //   }
  //   prevTokensRef.current = tokens;
  // }, [tokens]);

  // useEffect(() => {
  //   console.log('[DEBUG] outerScale is now', scale);
  // }, [scale]);

  // useEffect(() => {
  //   console.log('[DEBUG] Combat state:', inCombat);
  // }, [inCombat]);


  // Grid config - memoized as it depends only on constants
  const gridConfig = useMemo(() => ({
    squareSize: DEFAULT_SQUARE_SIZE,
    hexSize: DEFAULT_HEX_SIZE,
    hexWidth: Math.sqrt(3) * DEFAULT_HEX_SIZE,
    hexHeight: DEFAULT_HEX_SIZE * 2
  }), []);

  const { getSnappedPosition } = useGridSnapping({
    isHexGrid,
    gridSize: gridConfig.squareSize,
    hexWidth: gridConfig.hexWidth,
    hexHeight: gridConfig.hexHeight,
  });

  // Dimensions for dynamic grid layout - update on resize
  const [dimensions, setDimensions] = useState({ rows: 0, cols: 0 });

  const updateGridDimensions = useMemo(() => _.debounce(() => {
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    // Need to account for the width of the sidebar and toolbar
    const toolbarWidth = 60; // Matches CSS
    const sidebarWidth = 350; // Matches CSS split default size, adjust if collapsible
    const availableWidth = vw - toolbarWidth - (document.querySelector('.right-sidebar:not(.collapsed)')?.offsetWidth || 350); // Rough estimate
    const availableHeight = vh; // Assuming no top/bottom bars

    if (isHexGrid) {
      const effHeight = gridConfig.hexHeight * 0.75;
      setDimensions({
        rows: Math.ceil(availableHeight / effHeight) + 2, // Add padding rows
        cols: Math.ceil(availableWidth / gridConfig.hexWidth) + 2 // Add padding columns
      });
    } else {
      setDimensions({
        rows: Math.ceil(availableHeight / gridConfig.squareSize) + 2, // Add padding rows
        cols: Math.ceil(availableWidth / gridConfig.squareSize) + 2 // Add padding columns
      });
    }
  }, 200), [isHexGrid, gridConfig]); // Debounce the update

  useEffect(() => {
    updateGridDimensions();
    window.addEventListener('resize', updateGridDimensions);
    // Re-calculate dimensions if isHexGrid or sidebar size changes
    // Need to monitor sidebar size change... could use a ResizeObserver or pass width from SplitPane
    // For simplicity now, just trigger on isHexGrid change.
    updateGridDimensions(); 

    return () => {
      updateGridDimensions.cancel(); // Cancel debounce on cleanup
      window.removeEventListener('resize', updateGridDimensions);
    };
  }, [updateGridDimensions, isHexGrid]); // Re-run effect if updateGridDimensions memo changes (due to isHexGrid/gridConfig)

  // Calculate total grid dimensions based on rows/cols and size
  const { totalWidth, totalHeight } = useMemo(() => {
    if (isHexGrid) {
      // Total height needs to account for the last partial hex row
      const lastRowHeight = gridConfig.hexHeight * 0.75;
      const fullRowsHeight = (dimensions.rows - 1) * lastRowHeight;
      const finalHeight = fullRowsHeight + gridConfig.hexHeight; // Account for the full height of the last hex

      return {
        totalWidth: dimensions.cols * gridConfig.hexWidth,
        totalHeight: finalHeight,
      };
    } else {
      return {
        totalWidth: dimensions.cols * gridConfig.squareSize,
        totalHeight: dimensions.rows * gridConfig.squareSize,
      };
    }
  }, [dimensions, isHexGrid, gridConfig]);

  // Token drag - Pass setDirectState for intermediate updates
  const { startDrag } = useTokenDrag({
    scale: gameState.scale,
    getSnappedPosition,
    // onDragMove is called frequently during drag
    onDragMove: (tokenId, newPos) => { // No need for isFinal flag here
      // Use setDirectState for frequent, non-history-tracking updates
      setDirectState(prev => ({
        ...prev,
        tokens: prev.tokens.map(t =>
          t.id === tokenId ? { ...t, position: newPos } : t
        )
      }));
    },
    // onDragEnd is called once when drag finishes
    onDragEnd: (tokenId, finalPos) => {
      if (finalPos) {
        // Use updateGameState for the final position to add to history
        updateGameState(prev => ({
          ...prev,
          tokens: prev.tokens.map(t =>
            t.id === tokenId ? { ...t, position: finalPos } : t
          )
        }));
        // console.log('[DEBUG] Token drag ended, final position saved to history'); // Removed excessive debug
      }
    }
  });

  // Context menu handlers
  const handleAddToken = useCallback((e) => {
    const container = document.getElementById('tabletop-container');
    const containerRect = container.getBoundingClientRect();

    const screenX = e.clientX - containerRect.left;
    const screenY = e.clientY - containerRect.top;

    // Convert screen coordinates to grid coordinates relative to the tabletop's current position and scale
    const gridX = (screenX - position.x) / scale;
    const gridY = (screenY - position.y) / scale;

    const snappedPos = getSnappedPosition(gridX, gridY);

    updateGameState(prev => ({
      ...prev,
      tokens: [
        ...prev.tokens,
        {
          id: `token-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
          position: snappedPos,
          stats: { hp: 100, maxHp: 100, name: 'New Token' }, // Example stats
        }
      ]
    }));
    // console.log('[DEBUG] Added token at', snappedPos); // Removed excessive debug
  }, [getSnappedPosition, position, scale, updateGameState]);

  const { showMenu } = useContextMenu({
    onAddToken: handleAddToken,
    onDeleteTokens: handleDeleteTokens // Pass the deletion handler
  });

  // PING LOGIC
  const [pings, setPings] = useState([]);
  const pingTimeoutRef = useRef(null);
  const isPingingRef = useRef(false);
  const mouseDownRef = useRef(null); // Store start position for ping/marquee threshold

  // Function to create a ping effect
  const createPing = useCallback((screenX, screenY) => {
     const container = document.getElementById('tabletop-container');
    const containerRect = container.getBoundingClientRect();

    // Convert screen coordinates to grid coordinates relative to the tabletop's current position and scale
    const gridX = (screenX - position.x) / scale;
    const gridY = (screenY - position.y) / scale;

    const newPing = { id: Date.now(), x: gridX, y: gridY, color: '#ff4444' }; // Color example
    setPings(prev => [...prev, newPing]);

    // Auto-remove ping after animation
    setTimeout(() => {
      setPings(prev => prev.filter(p => p.id !== newPing.id));
    }, 2000); // Match CSS animation duration
  }, [position.x, position.y, scale]); // Add dependencies

  // Clean up ping state if mouse is released or moved significantly before timeout
  const cancelPing = useCallback(() => {
    if (pingTimeoutRef.current) {
      clearTimeout(pingTimeoutRef.current);
      pingTimeoutRef.current = null;
    }
    isPingingRef.current = false;
    // console.log('[DEBUG] Ping cancelled.'); // Removed excessive debug
  }, []);

  const handleMouseUp = useCallback((e) => {
     // Delegate to useZoomableContainer's handleMouseUp first?
     // The ZoomableContainer handles RMB panning. We need to handle LMB events here for drag/select/ping.

    // If a ping was potentially pending, clear the timeout
    cancelPing();
    mouseDownRef.current = null; // Reset mouse down state


    // If this was a simple click (not a drag or marquee) on empty space
    // This logic is handled in handleMouseDown/handleMouseMove combination now.
    // MouseUp on empty space *after* no drag -> click event (handled by context menu / future click logic)


  }, [cancelPing]);


  // Main mouse down handler for tabletop interactions (selection, drag, ping start)
  const handleMouseDown = useCallback((e) => {
    // console.log('[DEBUG-TABLETOP] MouseDown event:', { // Removed excessive debug
    //   button: e.button,
    //   target: e.target,
    //   ctrlKey: e.ctrlKey,
    //   metaKey: e.metaKey, // Cmd key on Mac
    //   defaultPrevented: e.defaultPrevented,
    //   className: e.target.className,
    //   id: e.target.id,
    // });

    // Ignore right-click, handled by ZoomableContainer for panning/context menu
    if (e.button === 2) return;

    const tokenEl = e.target.closest('.token');
    // Determine if additive selection (Ctrl/Cmd)
    const isAdditive = e.metaKey || e.ctrlKey;

    // Get container for coordinates
    const container = document.getElementById('tabletop-container');
    const containerRect = container.getBoundingClientRect();
    const screenX = e.clientX - containerRect.left;
    const screenY = e.clientY - containerRect.top;

    // Record initial mouse down position for drag/marquee/ping threshold
    mouseDownRef.current = {
        startScreenX: screenX,
        startScreenY: screenY,
        hasMoved: false, // Flag to track if significant movement occurred
        timestamp: Date.now(), // For ping timing
        isMarqueeOrPingIntent: !tokenEl // Intent is marquee or ping if clicked empty space
    };


    if (tokenEl) {
      // Clicked a token
      e.stopPropagation(); // Stop event from bubbling to tabletop/container pan listeners

      const clickedToken = tokens.find(t => t.id === tokenEl.id);
      const wasSelected = selectedTokenIds.has(tokenEl.id);

      // Logic for selecting tokens
      if (!isAdditive && !wasSelected) {
         // If not additive and token wasn't selected, clear current selection and select this one
        clearSelection();
        selectTokenId(tokenEl.id);
         // Start drag for THIS token only
         startDrag(clickedToken, e, [clickedToken]);

      } else if (isAdditive) {
         // If additive, toggle selection for this token
         selectTokenId(tokenEl.id, true);
         // If it becomes selected (or was already), start drag with ALL current selected tokens
         // Note: startDrag needs the LATEST set of selected tokens AFTER the selectTokenId call
         // This is a bit tricky with state updates being async.
         // A simpler approach is to always start drag if a token is clicked, the drag hook
         // decides WHICH tokens move based on the selection set it receives.
         // Let's rely on the drag hook being passed the current selection state correctly.
          const latestSelectedIds = isAdditive 
            ? (wasSelected ? new Set([...selectedTokenIds].filter(id => id !== tokenEl.id)) : new Set([...selectedTokenIds, tokenEl.id]))
            : new Set([tokenEl.id]);
          const tokensToDrag = tokens.filter(t => latestSelectedIds.has(t.id));
          startDrag(clickedToken, e, tokensToDrag); // Pass the potentially new selection state

      } else if (wasSelected && !isAdditive) {
         // If token was already selected and not additive click, keep selection as is
         // Start drag with ALL currently selected tokens
         const selectedTokens = tokens.filter(t => selectedTokenIds.has(t.id));
         startDrag(clickedToken, e, selectedTokens);
      }

    } else {
      // Clicked on empty space
      // Potentially start marquee selection or ping
      e.stopPropagation(); // Stop from bubbling to container (important for pan listener)
      e.preventDefault(); // Prevent default behavior like text selection

      // If not additive, clear selection immediately on empty space click down
      if (!isAdditive) {
        clearSelection();
      }

      // Start timer for ping (if mouse doesn't move significantly)
      isPingingRef.current = true;
      if (pingTimeoutRef.current) {
        clearTimeout(pingTimeoutRef.current);
      }
      // Set ping timeout to fire if mouse is still down after 500ms AND hasn't moved significantly
      pingTimeoutRef.current = setTimeout(() => {
        if (isPingingRef.current && mouseDownRef.current && !mouseDownRef.current.hasMoved) {
          // Ping at the mouse down screen coordinates
          createPing(mouseDownRef.current.startScreenX, mouseDownRef.current.startScreenY);
          isPingingRef.current = false; // Ping fired, stop tracking this potential ping
        }
        pingTimeoutRef.current = null; // Clear timeout ref
      }, 500);
    }
  }, [clearSelection, selectTokenId, tokens, selectedTokenIds, startDrag, position, scale, createPing, cancelPing]);


  // Main mouse move handler for tabletop interactions (drag, marquee)
  const handleMouseMove = useCallback((e) => {
    // If we are dragging a token, the useTokenDrag hook handles it via global listeners
    // console.log('[DEBUG-TABLETOP] MouseMove event'); // Removed excessive debug

    if (!mouseDownRef.current || isDraggingRef.current) return; // Only proceed if mouse is down and not already dragging

    const { startScreenX, startScreenY, hasMoved, isMarqueeOrPingIntent } = mouseDownRef.current;

    const currentScreenX = e.clientX;
    const currentScreenY = e.clientY;

    const dx = currentScreenX - startScreenX;
    const dy = currentScreenY - startScreenY;
    const distance = Math.sqrt(dx*dx + dy*dy);

    // Check for movement threshold to determine if it's a drag/marquee instead of a click/ping
    if (!hasMoved && distance > 5) { // Threshold = 5 pixels
      // console.log('[DEBUG] Movement threshold exceeded => start marquee/drag or cancel ping'); // Removed excessive debug
      mouseDownRef.current.hasMoved = true; // Mark as moved

      // If there was a pending ping, cancel it
      cancelPing();

      // If the initial intent was marquee/ping (clicked empty space)
      if (isMarqueeOrPingIntent) {
          // Start marquee selection (useTokenSelection handles its own mousemove/mouseup listeners)
          // Pass the original mouse down event which contains starting clientX/Y
          // Use requestAnimationFrame to avoid layout thrashing if marquee logic updates DOM frequently
          requestAnimationFrame(() => startMarquee(e));
      }
      // Note: If the intent was token drag, the drag started in handleMouseDown
    }
  }, [startMarquee, cancelPing]); // Added dependencies


  // Context menu handler - only show if not dragging/panning
  const handleContextMenu = useCallback((e) => {
    // Use state/ref to check if we were panning (handled by ZoomableContainer)
    // Or if we just finished a drag/marquee (handled by mouseDownRef)
    // Note: ZoomableContainer prevents default on its own contextmenu listener if panning occurred.
    // We prevent default *again* here just in case, then check if we should show the menu.
    e.preventDefault();
    e.stopPropagation();

    // Check if the mouse was moved significantly since mouseDown (indicates drag/marquee)
    // Check against the mouseDownRef's hasMoved flag set in handleMouseMove
    if (mouseDownRef.current?.hasMoved) {
       // console.log('[DEBUG] Context menu blocked due to recent movement'); // Removed excessive debug
       mouseDownRef.current = null; // Reset ref after handling event
       return; // Block menu if dragging/marquee happened
    }

    // Determine if context menu was on a token or the grid
    const tokenEl = e.target.closest('.token');
    showMenu(e, {
      type: tokenEl ? 'token' : 'grid'
    });
    // console.log('[DEBUG] Showing context menu'); // Removed excessive debug
    mouseDownRef.current = null; // Reset ref after showing menu


  }, [showMenu, mouseDownRef]); // Added mouseDownRef as dependency


  // Toggle Grid type (Square/Hex)
  const onToggleGrid = useCallback(() => {
    updateGameState(prev => ({
      ...prev,
      isHexGrid: !prev.isHexGrid
    }));
    // console.log('[DEBUG] Toggled grid'); // Removed excessive debug
  }, [updateGameState]);

  // Combat Toggle
  const onToggleCombat = useCallback(() => {
    updateGameState(prev => ({
      ...prev,
      inCombat: !prev.inCombat,
      // Optionally clear action history when ending combat
      actionHistory: !prev.inCombat ? prev.actionHistory : [] // Keep history when starting, clear when ending
    }));
    // console.log('[DEBUG] Toggled combat'); // Removed excessive debug
  }, [updateGameState]);

  // Add Action to History (placeholder)
  const addActionToHistory = useCallback((action) => {
    updateGameState(prev => ({
      ...prev,
      actionHistory: [...prev.actionHistory, { ...action, timestamp: Date.now(), id: Date.now() + Math.random() }]
    }));
    // console.log('[DEBUG] Added action to history:', action); // Removed excessive debug
  }, [updateGameState]);

  // Handle Dice Roll command from Chat/Input
  const handleDiceCommand = useCallback((command) => {
    const result = diceManager.handleCommand(command);
    if (result) {
       // Add roll result to action history/chat history
       // Decide where rolls go - chat? combat log? both?
       // For now, let's add rolls to action history if in combat, otherwise maybe just chat (need separate chat state?)
       // Let's update the Sidebar to handle chat state internally, and pass roll results up
       // The VirtualTabletop will then decide if it updates main state (e.g. adds action to history)

       // Placeholder: Log rolls to console and add basic action history entry if combat is on
       if (inCombat) {
           addActionToHistory({ type: 'Dice Roll', details: result.text, total: result.total });
       }
       return result; // Return result for the UI component (Sidebar) to display
    }
     return null; // Command not handled or no result
  }, [diceManager, inCombat, addActionToHistory]); // Added dependencies


  // 11) Render
  return (
    // SplitPane manages the horizontal split between the tabletop view and the sidebar
    <SplitPane
      split="vertical"
      defaultSize={window.innerWidth - 350} // Default size for the left (tabletop) pane
      minSize={400}       // Minimum width for the tabletop
      maxSize={-350}      // Max width for the tabletop (or min size for right pane: -350)
      className="app-layout-split-pane" // Optional class for styling split pane
    >
      {/* LEFT: The actual tabletop area */}
      <div className="main-content"> {/* This div is the left pane of the SplitPane */}
        {/* Zoom controls, undo, etc. could go here */}
        {/* <Controls onZoomIn={() => handleZoomButtons(1.1)} onZoomOut={() => handleZoomButtons(0.9)} /> */}
         {/* Zoom controls are now managed internally by ZoomableContainer hook via mouse wheel.
             If button controls are needed, uncomment the Controls component and pass a handler
             that calls handleZoomButtons from useZoomToMouse (need to get handleZoomButtons from hook)
         */}

        {/* The main container for the tabletop content */}
        <ZoomableContainer
          containerId="tabletop-container" // ID for the main container
          scale={scale}
          position={position}
          setScale={setScale} // Pass the history-tracking setter
          setPosition={setPosition} // Pass the history-tracking setter
          minScale={MIN_SCALE}
          maxScale={MAX_SCALE}
          zoomFactor={ZOOM_FACTOR}
          // onContextMenu is handled by ZoomableContainer for pan blocking, then delegated below
          gridWidth={totalWidth} // Pass calculated grid dimensions
          gridHeight={totalHeight}
        >
          <div
            id="tabletop" // ID for the pannable/zoomable content div
            className={`tabletop ${isHexGrid ? 'hex-grid' : 'square-grid'}`} // Add class for grid type
            // Tabletop content div handles MOUSE DOWN, MOVE, UP for token drag, selection, ping START
            // Context menu is handled by ZoomableContainer which sits *above* this for pan blocking
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            // Note: ContextMenu is handled by ZoomableContainer to prevent menu on pan/drag end
            // onContextMenu={handleContextMenu} // Removed - handled by ZoomableContainer
            style={{
              width: totalWidth, // Use calculated total grid size
              height: totalHeight, // Use calculated total grid size
              position: 'relative', // Needs to be relative for absolute tokens/grid
              userSelect: 'none' // Prevent selecting page elements during drag/pan
            }}
          >
            {/* Render Grid */}
            {dimensions.rows > 0 && dimensions.cols > 0 && (
              <Grid
                isHexGrid={isHexGrid}
                rows={dimensions.rows}
                cols={dimensions.cols}
                squareSize={gridConfig.squareSize}
                hexSize={gridConfig.hexSize}
                hexWidth={gridConfig.hexWidth}
                hexHeight={gridConfig.hexHeight}
              />
            )}

            {/* Render Tokens */}
            {tokens.map(token => (
              <Token
                key={token.id}
                id={token.id}
                position={token.position}
                stats={token.stats}
                isSelected={selectedTokenIds.has(token.id)}
                onClick={(e) => e.stopPropagation()} // Prevent token click from bubbling to tabletop click
              />
            ))}

            {/* Render Pings */}
            {pings.map(ping => (
              <Ping key={ping.id} x={ping.x} y={ping.y} color={ping.color} />
            ))}
          </div>
        </ZoomableContainer>
      </div>

      {/* RIGHT: The Sidebar with DM Tools, Chat, Combat Log */}
      <div className="right-sidebar"> {/* This div is the right pane of the SplitPane */}
        <Sidebar
          isHexGrid={isHexGrid}
          onToggleGrid={onToggleGrid}
          inCombat={inCombat}
          onToggleCombat={onToggleCombat}
          actionHistory={actionHistory}
          addActionToHistory={addActionToHistory} // Pass handler to add custom actions
          diceManager={diceManager} // Pass dice manager
          systemManager={systemManager} // Pass system manager
          // Pass history/undo state/handlers
          canUndo={historyInfo.canUndo}
          undoGameState={undoGameState}
          // canRedo={historyInfo.canRedo} // Add if redo button is implemented
          // redoGameState={redoGameState} // Add if redo button is implemented
        />
      </div>
    </SplitPane>
  );
}