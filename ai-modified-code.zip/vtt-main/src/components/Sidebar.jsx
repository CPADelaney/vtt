// src/components/Sidebar.jsx

import React, { useState, useRef, useEffect, useCallback } from 'react';
// Assuming lucide-react is installed. If not, replace with simple SVG imports.
import { ChevronLeft, ChevronRight, Swords, MessageSquare, History, Settings, Dice5 } from 'lucide-react';

// Simple Message component definition (moved from removed init.jsx)
const Message = ({ message }) => {
    const getMessageStyle = () => {
        switch (message.type) {
            case 'roll':
                return 'bg-blue-100 border-blue-400'; // Light blue background for rolls
            case 'system':
                return 'bg-yellow-100 border-yellow-400'; // Light yellow for system messages
            case 'error':
                return 'bg-red-100 border-red-400'; // Light red for errors
            default:
                return 'bg-gray-100 border-gray-300'; // Light gray for standard messages
        }
    };

    return (
        <div className={`p-2 rounded border-l-4 ${getMessageStyle()}`}>
            <span className="font-bold text-gray-800">{message.sender}: </span>
            {message.type === 'roll' ? (
                <div>
                    <div>{message.text}</div>
                    <div className="text-sm text-blue-700 font-bold mt-1">
                        Total: {message.total}
                    </div>
                </div>
            ) : (
                <span className="text-gray-700">{message.text}</span>
            )}
        </div>
    );
};


export const Sidebar = ({
  isHexGrid,
  onToggleGrid,
  inCombat,
  onToggleCombat,
  actionHistory, // Array of combat actions
  addActionToHistory, // Handler to add custom actions
  diceManager, // DiceManager instance
  systemManager, // SystemManager instance
  canUndo, // From useStateWithHistory
  undoGameState, // From useStateWithHistory
  // canRedo, // Optional: From useStateWithHistory
  // redoGameState, // Optional: From useStateWithHistory
}) => {
  // State for sidebar expansion (controlled internally)
  const [isExpanded, setIsExpanded] = useState(true);
  // State for active tab ('dm', 'chat')
  const [activeTab, setActiveTab] = useState('chat'); // Start on chat tab? Or DM?
  // State for active sub-tab in chat ('messages', 'combat')
  const [activeSubTab, setActiveSubTab] = useState('messages');
  // State for chat messages (managed internally by sidebar)
  const [messages, setMessages] = useState([]);

  // Ref for scrolling chat/log to bottom
  const messagesEndRef = useRef(null);
  // Ref for chat input field
  const inputRef = useRef(null);

  // Scroll to bottom when messages or history change and the relevant tab is active
  useEffect(() => {
    if (messagesEndRef.current && ((activeTab === 'chat' && activeSubTab === 'messages') || (activeTab === 'chat' && activeSubTab === 'combat'))) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, actionHistory, activeTab, activeSubTab]);

  // Handle sending message or command from input
  const handleMessageSend = useCallback((e) => {
    if (e.key === 'Enter') {
      const input = inputRef.current.value.trim();
      if (!input) return; // Don't send empty messages

      if (input.startsWith('/')) {
          // Handle as a command (dice roll)
          const result = diceManager?.handleCommand(input);
          if (result) {
              setMessages(prev => [...prev, { id: Date.now(), type: result.type, sender: result.sender, text: result.text, total: result.total }]);
              // Optional: Add rolls to action history if in combat
              if (inCombat && result.type === 'roll') {
                  addActionToHistory({ type: 'Dice Roll', details: result.text, total: result.total });
              }
          } else {
               // Handle potential errors from command parsing
               setMessages(prev => [...prev, { id: Date.now(), type: 'error', sender: 'System', text: `Unknown command or syntax error: ${input}` }]);
          }
      } else {
          // Handle as a regular chat message
          setMessages(prev => [...prev, { id: Date.now(), type: 'message', sender: 'DM', text: input }]); // Assuming DM for now
      }

      inputRef.current.value = ''; // Clear input
      inputRef.current.focus(); // Keep focus on input
    }
  }, [diceManager, inCombat, addActionToHistory]); // Added dependencies

  // Handle quick roll buttons
  const handleQuickRoll = useCallback((diceType) => {
      const command = `/roll 1${diceType}`;
      const result = diceManager?.handleCommand(command);
      if (result) {
           setMessages(prev => [...prev, { id: Date.now(), type: result.type, sender: result.sender, text: result.text, total: result.total }]);
           // Optional: Add rolls to action history if in combat
           if (inCombat && result.type === 'roll') {
              addActionToHistory({ type: 'Dice Roll', details: result.text, total: result.total });
           }
      }
  }, [diceManager, inCombat, addActionToHistory]); // Added dependencies


  // Handle Grid Toggle - Pass the handler up to VirtualTabletop
  const handleGridToggle = useCallback(() => {
    onToggleGrid(); // Call the handler passed from VirtualTabletop
  }, [onToggleGrid]);

  // Handle Combat Toggle - Pass the handler up to VirtualTabletop
  const handleCombatToggle = useCallback(() => {
    onToggleCombat(); // Call the handler passed from VirtualTabletop
     // Add a system message to chat history when combat starts/ends
     setMessages(prev => [...prev, { id: Date.now(), type: 'system', sender: 'System', text: inCombat ? 'Combat ended.' : 'Combat started!' }]);
  }, [onToggleCombat, inCombat]); // Added inCombat dependency for message text


  // Handle Undo button click
  const handleUndoClick = useCallback(() => {
    if (canUndo) {
      undoGameState();
       // Optional: Add system message about undo
       setMessages(prev => [...prev, { id: Date.now(), type: 'system', sender: 'System', text: 'Undo successful.' }]);
    } else {
        setMessages(prev => [...prev, { id: Date.now(), type: 'system', sender: 'System', text: 'Nothing to undo.' }]);
    }
  }, [canUndo, undoGameState]);


    // Placeholder for Revert Turn logic (requires combat tracker implementation)
    const handleRevertTurn = () => {
        // Logic to revert to the start of the current turn
        console.warn("Revert Turn not yet implemented.");
        setMessages(prev => [...prev, { id: Date.now(), type: 'system', sender: 'System', text: 'Revert Turn not yet implemented.' }]);
    };


  return (
    <div
      className={`right-sidebar ${isExpanded ? '' : 'collapsed'} flex flex-col`} // Use flex-col for internal layout
    >
      {/* Collapse/Expand Button */}
       {/* Position the button on the left edge of the sidebar container */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="flex-shrink-0 p-2 bg-white border-r border-l-0 border-t border-b border-gray-300 self-center"
        title={isExpanded ? 'Collapse Sidebar' : 'Expand Sidebar'}
      >
        {isExpanded ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
      </button>

      {isExpanded && (
        <div className="sidebar-content flex flex-col"> {/* Use flex-col for content layout */}
            {/* Header (Optional) */}
            {/* <div className="p-4 border-b flex-shrink-0">
                <h2 className="font-bold text-lg flex items-center">
                  <Swords size={20} className="mr-2" />
                   DM Controls / Chat
                </h2>
            </div> */}

            {/* Tabs */}
            <div className="sidebar-tabs flex-shrink-0">
                <button
                    onClick={() => setActiveTab('dm')}
                    className={`sidebar-tab-button ${activeTab === 'dm' ? 'active' : ''}`}
                >
                    <Settings size={16} className="mr-2" />
                    DM Tools
                </button>
                <button
                    onClick={() => setActiveTab('chat')}
                    className={`sidebar-tab-button ${activeTab === 'chat' ? 'active' : ''}`}
                >
                    <MessageSquare size={16} className="mr-2" />
                    Chat & Log
                </button>
            </div>

            {/* Content Area - Uses flex-grow to fill remaining space */}
            {/* This area will contain either DM Tools or Chat/Log based on activeTab */}
            <div className="sidebar-content-area flex-grow flex flex-col">

                {/* DM Tools Tab Content */}
                {activeTab === 'dm' && (
                    <div className="dm-tools-area">
                        {/* System Selector */}
                        <div className="space-y-1">
                            <label htmlFor="game-system-select" className="block text-sm font-medium text-gray-700">
                                Game System
                            </label>
                            <select
                                id="game-system-select"
                                className="w-full px-3 py-2 border rounded shadow-sm focus:ring-blue-500 focus:border-blue-500"
                                onChange={(e) => systemManager?.setSystem(e.target.value)}
                                value={systemManager?.currentSystemId || ''}
                                disabled={systemManager?.isValidating}
                            >
                                {systemManager?.isValidating && <option value="">Loading Systems...</option>}
                                {systemManager?.getAvailableSystems().map(system => (
                                    <option key={system.id} value={system.id}>
                                        {system.name}
                                    </option>
                                ))}
                                {!systemManager?.isValidating && systemManager?.getAvailableSystems().length === 0 && (
                                     <option value="">No Systems Available</option>
                                )}
                            </select>
                        </div>

                        {/* Combat Toggle */}
                        <button
                            onClick={handleCombatToggle}
                            className={inCombat ? 'btn-combat-end' : 'btn-combat-start'}
                        >
                            {inCombat ? 'End Combat' : 'Start Combat'}
                            <Swords size={16} className="ml-2 inline-block" />
                        </button>

                         {/* Grid Toggle */}
                        <button
                            onClick={handleGridToggle}
                             className="btn-grid-toggle text-white"
                        >
                            {isHexGrid ? 'Switch to Square Grid' : 'Switch to Hex Grid'}
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-2 inline-block"><rect width="18" height="18" x="3" y="3" rx="2"></rect><path d="M3 9h18"></path><path d="M3 15h18"></path><path d="M9 3v18"></path><path d="M15 3v18"></path></svg>
                        </button>

                         {/* Undo/Redo Controls */}
                        <div className="flex space-x-2">
                             <button
                                 onClick={handleUndoClick}
                                 disabled={!canUndo}
                                 className="flex-1 bg-blue-500 hover:bg-blue-600 text-white disabled:opacity-50 disabled:cursor-not-allowed"
                             >
                                 Undo ({actionHistory.length})
                                 <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="ml-1 inline-block"><path d="M3 3v5h5"></path><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"></path></svg>
                             </button>
                             {/* Redo button could go here */}
                         </div>
                    </div>
                )}

                {/* Chat & Log Tab Content */}
                {activeTab === 'chat' && (
                    <div className="flex flex-col h-full">
                        {/* Chat Subtabs */}
                        <div className="sidebar-tabs bg-gray-50 flex-shrink-0">
                            <button
                                onClick={() => setActiveSubTab('messages')}
                                className={`sidebar-tab-button text-sm ${activeSubTab === 'messages' ? 'active' : ''}`}
                            >
                                <MessageSquare size={14} className="mr-1" />
                                Messages
                            </button>
                            <button
                                onClick={() => setActiveSubTab('combat')}
                                className={`sidebar-tab-button text-sm ${activeSubTab === 'combat' ? 'active' : ''}`}
                            >
                                <History size={14} className="mr-1" />
                                Combat Log ({actionHistory.length})
                            </button>
                        </div>

                        {/* Content Area for Messages or Combat Log */}
                        <div className="sidebar-content-area flex-grow overflow-y-auto p-2 space-y-2"> {/* Adjusted padding here */}
                            {activeSubTab === 'messages' ? (
                                <div className="chat-messages">
                                    {messages.map(msg => (
                                        <Message key={msg.id} message={msg} />
                                    ))}
                                     {/* Dummy div to scroll into view */}
                                    <div ref={messagesEndRef} />
                                </div>
                            ) : (
                                <div className="combat-log">
                                    {actionHistory.length === 0 ? (
                                        <div className="text-center text-gray-500 italic">
                                            {inCombat ? 'No actions yet.' : 'Combat log is cleared when combat ends.'}
                                        </div>
                                    ) : (
                                        actionHistory.map((action, i) => (
                                            <div key={action.id || i} className="combat-log-item">
                                                <div className="font-semibold text-gray-800">{action.type}</div>
                                                {action.details && <div className="text-xs text-gray-600">{action.details}</div>}
                                                {/* You could add more details here depending on action type */}
                                                <div className="text-xs text-gray-500 mt-1">
                                                    {new Date(action.timestamp).toLocaleTimeString()}
                                                </div>
                                            </div>
                                        ))
                                    )}
                                     {/* Dummy div to scroll into view */}
                                    <div ref={messagesEndRef} />
                                </div>
                            )}

                        </div>

                        {/* Input Area - Only for chat messages sub-tab */}
                        {activeSubTab === 'messages' && (
                           <div className="chat-input-area flex-shrink-0 p-2"> {/* Adjusted padding */}
                              <input
                                 ref={inputRef}
                                 type="text"
                                 placeholder="Type /roll XdY or a message..."
                                 className="w-full px-2 py-1 border rounded"
                                 onKeyPress={handleMessageSend}
                              />
                                <div className="chat-quick-rolls">
                                    {['d4', 'd6', 'd8', 'd10', 'd12', 'd20'].map(die => (
                                        <button
                                            key={die}
                                            onClick={() => handleQuickRoll(die)}
                                        >
                                            <Dice5 size={14} className="inline-block mr-1"/>{die}
                                        </button>
                                    ))}
                                </div>
                           </div>
                        )}
                    </div>
                )}
            </div>
        </div>
      )}
    </div>
  );
};