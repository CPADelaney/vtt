import React, { useEffect } from 'react';
import '../css/styles.css'; // Ensure styles are imported

/**
 * Renders a temporary visual "ping" effect at a given position.
 * Uses CSS animation for the effect.
 *
 * @param {number} x - X coordinate (grid/world space)
 * @param {number} y - Y coordinate (grid/world space)
 * @param {string} [color='#ff4444'] - Color of the ping
 * @param {Function} [onComplete] - Callback function called after animation finishes
 */
export const Ping = ({ x, y, color = '#ff4444', onComplete }) => {

  useEffect(() => {
    // Set a timer to call onComplete after the CSS animation duration (2000ms)
    const timer = setTimeout(() => {
      onComplete?.();
    }, 2000); // Matches the animation duration in styles.css

    // Cleanup the timer
    return () => clearTimeout(timer);
  }, [onComplete]); // Only re-run effect if onComplete changes

  return (
    // The container positions the ping using the provided x, y coordinates
    <div
      className="ping-container"
      style={{
        position: 'absolute',
        left: `${x}px`,
        top: `${y}px`,
        // Note: transform: translate(-50%, -50%) should likely be on the children (.ping-outer, .ping-inner)
        // so that x,y is the intended center point *before* the children are offset.
        // Let's move translate to children styles.css or inline.
      }}
    >
       {/* Outer ring with animation */}
      <div
        className="ping-outer"
        style={{
          // Note: animation is defined in styles.css
          borderColor: color, // Set color via inline style
          // opacity and transform are managed by the CSS animation @keyframes pingAnimation
           transform: 'translate(-50%, -50%)', // Center the outer div on the container's point
           opacity: 0.5, // Start opacity before animation takes over
        }}
      />
       {/* Inner dot with animation */}
      <div
        className="ping-inner"
         style={{
           backgroundColor: color, // Set color via inline style
           // opacity and transform are managed by the CSS animation @keyframes pingAnimation
            transform: 'translate(-50%, -50%)', // Center the inner div on the container's point
            opacity: 1, // Start opacity before animation takes over
         }}
      />
    </div>
  );
};