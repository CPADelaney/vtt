// src/App.jsx
import React from 'react';
import VirtualTabletop from './components/VirtualTabletop';
import ToolsBar from './components/ToolsBar';
import { Sidebar } from './components/Sidebar'; // Use the refactored Sidebar
import '../css/styles.css';

// Assume global instances are available or passed down via Context if preferred
// For this refactoring, we'll assume they are globally accessible via window for simplicity,
// matching the likely intent of the removed init.jsx
const diceManager = window.diceManager;
const systemManager = window.systemManager;


export default function App() {
  // VirtualTabletop now manages its own core state (gameState, history, etc.)
  // and passes necessary pieces down.

  return (
    // Use the app-layout grid defined in CSS
    <div className="app-layout">
      {/* LEFT COLUMN (tools): 60px wide */}
      <div className="tools-bar">
        <ToolsBar />
      </div>

      {/* MIDDLE: VirtualTabletop (the main map area) */}
      <div className="main-content">
        {/* VirtualTabletop component now receives its state and history controls internally */}
        <VirtualTabletop 
          diceManager={diceManager} // Pass managers down if needed, though Sidebar uses them directly too
          systemManager={systemManager} // Pass managers down if needed
        />
      </div>

      {/* RIGHT: Sidebar (DM Tools, Chat, Combat Log) */}
      <div className="right-sidebar">
         {/* Sidebar component now receives its state and handlers internally from VirtualTabletop */}
         {/* VirtualTabletop will render Sidebar and pass props */}
      </div>
    </div>
  );
}

// Note: VirtualTabletop will be updated to manage its own state and render the Sidebar.
// This App component simply provides the structural layout.