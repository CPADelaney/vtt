import { useState, useCallback, useEffect } from 'react';

export function useTokenSelection() {
  const [selectedTokenIds, setSelectedTokenIds] = useState(new Set());
  const [marqueeState, setMarqueeState] = useState(null); // State to manage marquee visibility and properties

  const clearSelection = useCallback(() => {
    // console.log('[DEBUG] Selection cleared.'); // Removed excessive debug
    setSelectedTokenIds(new Set());
  }, []);

  // Toggle or set selection for a single token
  const selectTokenId = useCallback((tokenId, additive = false) => {
    setSelectedTokenIds(prev => {
      const newSet = additive ? new Set(prev) : new Set();

      if (additive && prev.has(tokenId)) {
        // If additive and already selected, remove it (toggle)
        newSet.delete(tokenId);
      } else {
        // Otherwise add it
        newSet.add(tokenId);
      }
      // console.log('[DEBUG] Single token selection update:', { tokenId, additive, newCount: newSet.size }); // Removed excessive debug
      return newSet;
    });
  }, []);

  // Set selection for multiple tokens (e.g., from marquee)
  const selectTokenIds = useCallback((tokenIds, additive = false) => {
    setSelectedTokenIds(prev => {
      const newSet = additive ? new Set(prev) : new Set();

      // If additive, toggle any tokens that are already selected among the new list
      if (additive) {
        tokenIds.forEach(id => {
          if (prev.has(id)) {
            newSet.delete(id);
          } else {
            newSet.add(id);
          }
        });
      } else {
        // If not additive, simply replace the selection with the new list
        tokenIds.forEach(id => newSet.add(id));
      }
      // console.log('[DEBUG] Multi token selection update:', { additive, newCount: newSet.size }); // Removed excessive debug
      return newSet;
    });
  }, []);

  /**
   * Starts the marquee selection process by creating and positioning the marquee element.
   * @param {MouseEvent} e - The mouse down event that initiates the marquee.
   */
  const startMarquee = useCallback((e) => {
    // console.log('[DEBUG] startMarquee called'); // Removed excessive debug
    // Get container element
    const container = document.getElementById('tabletop-container');
    if (!container) {
      console.error('Error: Tabletop container not found for marquee selection.');
      return;
    }

    // Create marquee element
    const marqueeEl = document.createElement('div');
    marqueeEl.className = 'marquee'; // Use the CSS class for styling

    // Get container bounds and calculate initial position relative to container
    const containerRect = container.getBoundingClientRect();
    const startX = e.clientX - containerRect.left;
    const startY = e.clientY - containerRect.top;

    // Apply inline styles for initial position and size (size is 0,0 initially)
    marqueeEl.style.position = 'absolute';
    marqueeEl.style.left = `${startX}px`;
    marqueeEl.style.top = `${startY}px`;
    marqueeEl.style.width = '0';
    marqueeEl.style.height = '0';
    // Other styles (border, background, pointer-events, z-index) should be in the .marquee CSS class

    // Add marquee element to the container
    container.appendChild(marqueeEl);

    // Store state for move/up handlers
    setMarqueeState({
      element: marqueeEl,
      startX, // Start position relative to container
      startY,
      containerRect // Store container dimensions/position
    });

    // console.log('[DEBUG] Marquee state initialized.'); // Removed excessive debug
  }, []);

  // Effect to manage global mousemove and mouseup listeners for the marquee
  useEffect(() => {
    // Only add listeners if marqueeState is active
    if (!marqueeState) return;

    const onMouseMove = (e) => {
      const { element, startX, startY, containerRect } = marqueeState;

      // Get current mouse position relative to container
      const currentX = e.clientX - containerRect.left;
      const currentY = e.clientY - containerRect.top;

      // Calculate marquee boundaries relative to container
      const minX = Math.min(currentX, startX);
      const maxX = Math.max(currentX, startX);
      const minY = Math.min(currentY, startY);
      const maxY = Math.max(currentY, startY);

      // Update marquee element's position & size
      element.style.left = `${minX}px`;
      element.style.top = `${minY}px`;
      element.style.width = `${maxX - minX}px`;
      element.style.height = `${maxY - minY}px`;
    };

    const onMouseUp = (e) => {
      const { element, containerRect } = marqueeState;

      // Get the final marquee rectangle relative to the container
      const marqueeRect = element.getBoundingClientRect();
      const marqueeLeft = marqueeRect.left - containerRect.left;
      const marqueeTop = marqueeRect.top - containerRect.top;
      const marqueeRight = marqueeRect.right - containerRect.left;
      const marqueeBottom = marqueeRect.bottom - containerRect.top;


      // Get all token elements within the *same container*
      const tokenEls = container.querySelectorAll('.token');
      const selectedTokens = new Set(); // Use a Set for efficient adding

      tokenEls.forEach(tokenEl => {
        const tokenRect = tokenEl.getBoundingClientRect();

        // Convert token bounding box coordinates to container space
        // Note: getBoundingClientRect() gives screen coords. We need to convert them.
        // Token's left/top relative to container:
        const tokenLeft = tokenRect.left - containerRect.left;
        const tokenTop = tokenRect.top - containerRect.top;
        const tokenRight = tokenRect.right - containerRect.left;
        const tokenBottom = tokenRect.bottom - containerRect.top;


        // Check for intersection between marqueeRect (in container space) and tokenRect (in container space)
        const intersects = !(
          marqueeRight < tokenLeft ||
          marqueeLeft > tokenRight ||
          marqueeBottom < tokenTop ||
          marqueeTop > tokenBottom
        );

        if (intersects) {
          selectedTokens.add(tokenEl.id);
        }
      });

      // Use shiftKey for additive selection with marquee
      selectTokenIds(selectedTokens, e.shiftKey);

      // Cleanup: remove marquee element and reset state
      element.remove();
      setMarqueeState(null);
      // console.log('[DEBUG] Marquee selection ended.'); // Removed excessive debug
    };

    // Add global listeners to capture events outside the container during drag
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);

    // Cleanup listeners on unmount or when marqueeState becomes null
    return () => {
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
       // Ensure marquee element is removed if component unmounts or marquee is cancelled another way
       if (marqueeState?.element && marqueeState.element.parentNode) {
           marqueeState.element.parentNode.removeChild(marqueeState.element);
       }
    };
  }, [marqueeState, selectTokenIds]); // Re-run effect if marqueeState or selectTokenIds changes

   // Cleanup marquee on component unmount
   useEffect(() => {
       return () => {
           if (marqueeState?.element && marqueeState.element.parentNode) {
               marqueeState.element.parentNode.removeChild(marqueeState.element);
           }
       };
   }, [marqueeState]); // Only needs marqueeState to access the element


  return {
    selectedTokenIds,
    selectTokenId, // For selecting a single token
    selectTokenIds, // For selecting a set of tokens (used by marquee)
    clearSelection,
    startMarquee // Function to initiate marquee selection
  };
}