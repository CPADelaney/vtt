import { useCallback, useEffect, useRef } from 'react';

/**
 * useTokenDrag hook
 * Manages the dragging logic for tokens on the tabletop.
 * Supports dragging multiple selected tokens together.
 *
 * @param {object} options
 *   @param {number} scale - The current scale of the tabletop.
 *   @param {Function} getSnappedPosition - Function to snap world coordinates to the grid.
 *   @param {Function} setDirectState - Callback to update token positions *without* adding to history (for intermediate drag moves). Accepts (tokenId, newPosition).
 *   @param {Function} updateState - Callback to update token positions *and* add to history (for the final drag position). Accepts (tokenId, newPosition).
 */
export function useTokenDrag({ scale, getSnappedPosition, setDirectState, updateState }) {
  // Refs for storing the latest props/state functions
  const scaleRef = useRef(scale);
  const getSnappedPositionRef = useRef(getSnappedPosition);
  // Use specific refs for the state update functions
  const setDirectStateRef = useRef(setDirectState);
  const updateStateRef = useRef(updateState);


  // Our drag state
  const dragStateRef = useRef(null);
  const isDraggingRef = useRef(false);

  // Update the refs when props change
  useEffect(() => {
    scaleRef.current = scale;
    getSnappedPositionRef.current = getSnappedPosition;
    setDirectStateRef.current = setDirectState; // Update ref for setDirectState
    updateStateRef.current = updateState;     // Update ref for updateState
  }, [scale, getSnappedPosition, setDirectState, updateState]); // Added setDirectState and updateState to dependencies

  // Attach global event listeners once (no dependencies) for performance
  useEffect(() => {
    function onMouseMove(e) {
      if (!isDraggingRef.current || !dragStateRef.current) return;
      const dragState = dragStateRef.current;

      // Prevent default selection behavior and stop propagation
      e.preventDefault();
      e.stopPropagation();

      const currentScale = scaleRef.current;
      const dx = (e.clientX - dragState.startMouseX) / currentScale;
      const dy = (e.clientY - dragState.startMouseY) / currentScale;

      // Use a map to build the updates to pass to setDirectState
      const positionsToUpdate = new Map();

      // Calculate new positions for all selected tokens
      dragState.tokenIds.forEach(tokenId => {
        const startPos = dragState.tokenStartPositions.get(tokenId);
        if (!startPos) return; // Should not happen if tokenStartPositions is built correctly

        const newX = startPos.x + dx;
        const newY = startPos.y + dy;

        const { x: snappedX, y: snappedY } = getSnappedPositionRef.current(newX, newY);

        // Store the updated position
        positionsToUpdate.set(tokenId, { x: snappedX, y: snappedY });
      });

      // Call the direct state setter ONCE with updates for all tokens
      // This prevents flooding history and is more efficient than per-token updates
      setDirectStateRef.current?.(prev => ({
         ...prev,
         tokens: prev.tokens.map(t => {
            const newPos = positionsToUpdate.get(t.id);
            return newPos ? { ...t, position: newPos } : t;
         })
      }));

      // console.log('[DEBUG] Mouse move update (direct state)'); // Removed excessive debug
    }

    function onMouseUp(e) {
      if (!isDraggingRef.current || !dragStateRef.current) return;
      const dragState = dragStateRef.current;

      // Prevent default selection behavior and stop propagation
      e.preventDefault();
      e.stopPropagation();

      const currentScale = scaleRef.current;
      const dx = (e.clientX - dragState.startMouseX) / currentScale;
      const dy = (e.clientY - dragState.startMouseY) / currentScale;

      // Use a map to build the final updates to pass to updateState (history tracking)
      const finalPositions = new Map();

      // Calculate final positions for all selected tokens
      dragState.tokenIds.forEach(tokenId => {
        const startPos = dragState.tokenStartPositions.get(tokenId);
        if (!startPos) return;

        const finalX = startPos.x + dx;
        const finalY = startPos.y + dy;

        const { x: snappedX, y: snappedY } = getSnappedPositionRef.current(finalX, finalY);

        finalPositions.set(tokenId, { x: snappedX, y: snappedY });
      });

      // Call the history-tracking state setter ONCE with final updates for all tokens
      updateStateRef.current?.(prev => ({
         ...prev,
         tokens: prev.tokens.map(t => {
            const finalPos = finalPositions.get(t.id);
            return finalPos ? { ...t, position: finalPos } : t;
         })
      }));

      // console.log('[DEBUG] Token drag ended (history state)'); // Removed excessive debug

      // Reset drag state
      isDraggingRef.current = false;
      dragStateRef.current = null;
      document.body.style.userSelect = ''; // Restore user selection
      document.body.style.cursor = ''; // Restore cursor
    }

    function onKeyDown(e) {
      if (e.key === 'Escape' && isDraggingRef.current) {
        console.log('[DEBUG] Drag cancelled via Escape key');
        // Option 1: Snap back to start position on cancel (more complex, needs start pos storage)
        // Option 2: Just stop dragging at current intermediate position (simpler)
        // Let's implement option 2 for now - the token is already at the intermediate position via setDirectState

        isDraggingRef.current = false;
        dragStateRef.current = null; // Clear state
        document.body.style.userSelect = ''; // Restore user selection
        document.body.style.cursor = ''; // Restore cursor
        e.preventDefault(); // Prevent other default Escape actions
      }
    }

    // Add listeners to the window/document to capture events globally, even if mouse leaves the VTT area
    // Use capture phase (true) to ensure these fire before potential React listeners on nested elements
    window.addEventListener('mousemove', onMouseMove, { capture: true });
    window.addEventListener('mouseup', onMouseUp, { capture: true });
    window.addEventListener('keydown', onKeyDown, { capture: true });


    // Cleanup listeners on unmount
    return () => {
      window.removeEventListener('mousemove', onMouseMove, { capture: true });
      window.removeEventListener('mouseup', onMouseUp, { capture: true });
      window.removeEventListener('keydown', onKeyDown, { capture: true });
    };
  }, []); // Empty dependency array: effect runs once on mount and cleans up on unmount

  // Single startDrag function - called by VirtualTabletop on mousedown on a token
  const startDrag = useCallback((initialToken, e, selectedTokens) => {
    // console.log('[DEBUG] Starting drag with tokens:', selectedTokens.map(t => t.id)); // Removed excessive debug

    // Check if selectedTokens is empty (shouldn't happen if called correctly)
    if (!selectedTokens || selectedTokens.length === 0) {
        // console.warn("startDrag called with no selected tokens."); // Removed excessive debug
        return;
    }

    // Build the map of initial positions for all tokens involved in the drag
    const tokenStartPositions = new Map();
    selectedTokens.forEach(token => {
      tokenStartPositions.set(token.id, {
        x: token.position.x,
        y: token.position.y
      });
    });

    // Store initial state in the ref
    dragStateRef.current = {
      tokenIds: selectedTokens.map(t => t.id),
      startMouseX: e.clientX,
      startMouseY: e.clientY,
      tokenStartPositions,
      // initialTimestamp: Date.now() // Not strictly needed for drag logic itself
    };

    isDraggingRef.current = true;
    document.body.style.userSelect = 'none'; // Prevent text selection during drag
    document.body.style.cursor = 'grabbing'; // Indicate dragging visually


    // console.log('[DEBUG] Drag state initialized.'); // Removed excessive debug

    // Important: Prevent default behavior and propagation on the initiating mousedown event
    // This stops it from interacting with lower layers (like pan or selection box start)
     e.preventDefault();
     e.stopPropagation();


  }, []); // Dependencies for startDrag: none, relies on refs updated by effect


  // Expose startDrag function and current dragging status
  return {
    startDrag,
    // isDragging: isDraggingRef.current // Note: Ref value won't trigger re-renders, may need state if UI depends on this
  };
}